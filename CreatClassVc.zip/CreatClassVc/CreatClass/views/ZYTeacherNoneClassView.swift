//
//  ZYTeacherNoneClassView.swift
//  iReader
//
//  Created by bestsu on 2018/9/20.
//  Copyright © 2018年 iOS Group. All rights reserved.
//

import UIKit

class ZYTeacherNoneClassView: UIView {

    /// 创建班级回调
    var creatClassCallBack: (()->())?
    override init(frame: CGRect) {
        super.init(frame: frame)
        setUI()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func setUI(){
        addSubview(iconImageView)
        addSubview(titleLabel)
        addSubview(creatClassBtn)
        
        iconImageView.mas_makeConstraints { (make) in
            make?.centerX.mas_equalTo()(self)
            make?.top.equalTo()(ceilStandardPtf(396))
            make?.size.mas_equalTo()(CGSize(width: ceilStandardPtf(404), height: ceilStandardPtf(464)))
        }
        
        titleLabel.mas_makeConstraints { (make) in
            make?.centerX.mas_equalTo()(self)
            make?.top.mas_equalTo()(iconImageView.mas_bottom)?.setOffset(ceilStandardPtf(100))
        }
        
        creatClassBtn.mas_makeConstraints { (make)  in
            make?.centerX.mas_equalTo()(self)
            make?.bottom.equalTo()(ceilStandardPtf(-360))
            make?.size.mas_equalTo()(CGSize(width: ceilStandardPtf(840), height: ceilStandardPtf(135)))
        }
    }

    @objc private func creatClassBtnClick(){
        creatClassCallBack?()
    }
    
    private lazy var iconImageView: UIImageView = {
        let view = UIImageView()
        view.image = UIImage.init(named: "Group 6")
        view.sizeToFit()
        return view
    }()
    
    private lazy var titleLabel: UILabel = {
        let label = UILabel()
        label.text = "暂无班级,创建班级可发布免费阅读计划哦~"
        label.textAlignment = .center
        label.textColor = UIColor.init(hex: 0x999999)
        label.font = UIFont.systemFont(ofSize: ceilStandardPtf(36))
        return label
    }()
    
    private lazy var creatClassBtn: UIButton = {
        let button = UIButton()
        button.adjustsImageWhenHighlighted = false
        button.setTitle("创建班级", for: .normal)
        button.setBackgroundImage(UIImage.init(named: "button"), for: .normal)
        button.titleLabel?.font = UIFont.systemFont(ofSize: ceilStandardPtf(48))
        button.setTitleColor(UIColor.white, for: .normal)
        button.addTarget(self, action: #selector(creatClassBtnClick), for: .touchUpInside)
        return button
    }()
}



