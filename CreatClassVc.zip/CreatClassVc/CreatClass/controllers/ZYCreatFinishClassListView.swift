//
//  ZYCreatFinishClassListView.swift
//  CreatClassDemo
//
//  Created by bestsu on 2018/9/18.
//  Copyright © 2018年 bestsu. All rights reserved.
//

import UIKit

class ZYCreatFinishClassListView: UIView, UICollectionViewDataSource{
    
    var classList: [ChoseClassStruct]?{
        didSet{
            self.collectionview.reloadData()
        }
    }
    
    /// 死数据不要动
    var classNameArr: [String] = ["一年级", "二年级", "三年级", "四年级", "五年级", "六年级", "七年级", "八年级", "九年级", "十年级", "十一年级", "十二年级"]
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.backgroundColor = UIColor.white
        setUI()
        loadData()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func setUI(){
        addSubview(collectionview)
        collectionview.mas_makeConstraints { (make) in
            make?.edges.mas_equalTo()(self)
//            make?.height.equalTo()(ceilStandardPtf(500))
        }
    }
    //  MARK: - collectionview的代理方法和数据源方法
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return classList?.count ?? 0
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        guard let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cellId", for: indexPath) as? CreatFinishClassListViewTabaelviewCell else{
            return UICollectionViewCell()
        }
        let gradeStr:String = classNameArr[(self.classList?[indexPath.row].grade ?? 0) - 1]
        let nameStr: String = gradeStr + "\(self.classList?[indexPath.row].classNumber ?? 0)" + "班"
        cell.className = nameStr
        return cell
    }
    
    
    //  MARK: loadData
//    var dataM: ZYStudentGetClassListInfoModel?
//    var dataTeacherM: [ZYStudentGetClassListInfoModel]?
    private func loadData(){
        ZYTeacherCreatClassManager().checkClassList(success: {(dataM) in
            print("finish")
//            self.dataM = dataM
//            self.dataTeacherM = dataM.teacher as? [ZYStudentGetClassListInfoModel]
        }) { (msg, code) in
            print(msg, code)
        }
    }
    
    
    
    
    
    private lazy var collectionview: UICollectionView = {
        let flowLayout = UICollectionViewFlowLayout()
        flowLayout.itemSize = CGSize(width: ceilStandardPtf(276), height: ceilStandardPtf(96))
        flowLayout.minimumLineSpacing = ceilStandardPtf(72)
        flowLayout.minimumInteritemSpacing = ceilStandardPtf(60)
        flowLayout.scrollDirection = UICollectionViewScrollDirection.vertical
        let view = UICollectionView(frame: CGRect.zero, collectionViewLayout: flowLayout)
        view.backgroundColor = UIColor.white
        view.dataSource = self
        view.showsHorizontalScrollIndicator = false
        view.contentInset = UIEdgeInsets(top: 0, left: ceilStandardPtf(60), bottom: 0, right: ceilStandardPtf(60))
        view.register(CreatFinishClassListViewTabaelviewCell.self, forCellWithReuseIdentifier: "cellId")
        return view
    }()
    
}


class CreatFinishClassListViewTabaelviewCell: UICollectionViewCell {
    
    var className: String?{
        didSet{
            self.titleLabel.text = className
        }
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.layer.cornerRadius = ceilStandardPtf(12)
        self.layer.masksToBounds = true
        self.layer.borderColor = UIColor.init(hex: 0x222222, alpha: 0.35).cgColor
        self.layer.borderWidth = ceilStandardPtf(2)
        setUI()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func setUI(){
        self.contentView.addSubview(titleLabel)
        titleLabel.mas_makeConstraints { (make) in
            make?.center.mas_equalTo()(contentView)
        }
    }
    
    private lazy var titleLabel: UILabel = {
        let label = UILabel()
        label.text = ""
        label.textAlignment = .center
        label.textColor = UIColor.init(hex: 0x222222, alpha: 0.35)
        label.font = UIFont.systemFont(ofSize: ceilStandardPtf(42))
        return label
    }()
    
}




