//
//  ZYFinishCreatClassViewController.swift
//  CreatClassDemo
//
//  Created by bestsu on 2018/9/18.
//  Copyright © 2018年 bestsu. All rights reserved.
//

import UIKit

class ZYFinishCreatClassViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = UIColor.white
        setItem()
        setUI()
    }
    /// 邀请码
    var teacherCode: String = ""
    convenience init(isFirst: Int, inviteCode: String, classArr: [ChoseClassStruct]){
        self.init()
        if isFirst == 1{ //是否第一次创建班级，0-不是第一次 1-是第一次
            vipLabel.isHidden = false
        }else{
            vipLabel.isHidden = true
        }
        self.teacherCode = inviteCode
        self.classListView.classList = classArr
    }
    
    
    private func setItem(){
        self.navigationItem.leftBarButtonItem = UIBarButtonItem.init(title: "   完成创建班级", imageName: "channelClose", titleColor: UIColor.init(hex6: 0x222222), font: UIFont.systemFont(ofSize: ceilStandardPtf(51)), target: self, action: #selector(leftClick))
    }
    
    @objc private func leftClick(){
        self.navigationController?.popViewController(animated: true)
    }
    
    private func setUI(){
        view.addSubview(iconImageView)
        view.addSubview(infoLabel)
        view.addSubview(vipLabel)
        view.addSubview(titleLabel)
        view.addSubview(leftLineView)
        view.addSubview(rightLineView)
        view.addSubview(classListView)
        view.addSubview(inviteStudentBtnView)
        
        iconImageView.mas_makeConstraints { (make) in
            make?.centerX.mas_equalTo()(view)
            make?.top.equalTo()(ceilStandardPtf(183))
            make?.size.mas_equalTo()(CGSize(width: ceilStandardPtf(290), height: ceilStandardPtf(290)))
        }
        
        infoLabel.mas_makeConstraints { (make) in
            make?.centerX.mas_equalTo()(view)
            make?.top.mas_equalTo()(iconImageView.mas_bottom)?.setOffset(ceilStandardPtf(85))
        }
        
        vipLabel.mas_makeConstraints { (make) in
            make?.centerX.mas_equalTo()(view)
            make?.top.mas_equalTo()(infoLabel.mas_bottom)?.setOffset(ceilStandardPtf(60))
        }
        
        titleLabel.mas_makeConstraints { (make) in
            make?.centerX.mas_equalTo()(view)
            make?.top.mas_equalTo()(vipLabel.mas_bottom)?.setOffset(ceilStandardPtf(180))
        }
        
        leftLineView.mas_makeConstraints { (make) in
            make?.right.mas_equalTo()(titleLabel.mas_left)?.setOffset(ceilStandardPtf(-12))
            make?.height.equalTo()(ceilStandardPtf(1))
            make?.centerY.mas_equalTo()(titleLabel)
            make?.left.equalTo()(ceilStandardPtf(66))
        }
        
        rightLineView.mas_makeConstraints { (make) in
            make?.left.mas_equalTo()(titleLabel.mas_right)?.setOffset(ceilStandardPtf(12))
            make?.height.equalTo()(ceilStandardPtf(1))
            make?.centerY.mas_equalTo()(titleLabel)
            make?.right.equalTo()(ceilStandardPtf(-66))
        }
        
        classListView.mas_makeConstraints { (make) in
            make?.left.right().mas_equalTo()(view)
            make?.top.mas_equalTo()(titleLabel.mas_bottom)?.setOffset(ceilStandardPtf(90))
            make?.height.equalTo()(ceilStandardPtf(500))
        }
        
        inviteStudentBtnView.mas_makeConstraints { (make) in
            make?.left.bottom().right().mas_equalTo()(view)
            make?.height.equalTo()(ceilStandardPtf(171))
        }
    }
    
    @objc private func inviteStudentBtnViewClick() {
        print("邀请学生")
        let vc = ZYTeacherInviteJoinClassViewController(inviteCode: self.teacherCode)
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    //  MARK:  懒加载控件
    private lazy var iconImageView: UIImageView = {
        let view = UIImageView()
        view.image = UIImage.init(named: "image_recharge_success")
        return view
    }()
    
    private lazy var infoLabel: UILabel = {
        let label = UILabel()
        label.text = "您的班级创建好了，快去邀请学生加入吧~"
        label.textAlignment = .center
        label.textColor = UIColor.init(hex: 0x2bc17c)
        label.font = UIFont.boldSystemFont(ofSize: ceilStandardPtf(48))
        return label
    }()
    
    private lazy var vipLabel: UILabel = {
        let label = UILabel()
        label.text = "您已获得7天VIP特权"
        label.isHidden = true
        label.textAlignment = .center
        label.textColor = UIColor.init(hex: 0x222222)
        label.font = UIFont.systemFont(ofSize: ceilStandardPtf(51))
        return label
    }()
    
    private lazy var titleLabel: UILabel = {
        let label = UILabel()
        label.text = "已创建班级"
        label.textAlignment = .center
        label.textColor = UIColor.init(hex: 0x222222, alpha: 0.35)
        label.font = UIFont.systemFont(ofSize: ceilStandardPtf(39))
        return label
    }()
    
    private lazy var leftLineView: UIView = {
        let view = UIView()
        view.backgroundColor = UIColor.init(hex: 0x222222, alpha: 0.25)
        return view
    }()
    
    private lazy var rightLineView: UIView = {
        let view = UIView()
        view.backgroundColor = UIColor.init(hex: 0x222222, alpha: 0.25)
        return view
    }()
    
    private lazy var classListView: ZYCreatFinishClassListView = {
        let view = ZYCreatFinishClassListView()
        return view
    }()
    
    private lazy var inviteStudentBtnView: ZYBestButtonView = {
        let view = ZYBestButtonView()
        view.isSelected = true
        view.titleName = "邀请学生"
        view.setImage(image: UIImage.init(named: "button copy"), for: .normal)
        view.setImage(image: UIImage.init(named: "button"), for: .selected)
        view.addTarget(self, action: #selector(inviteStudentBtnViewClick), for: .touchUpInside)
        return view
    }()

}





