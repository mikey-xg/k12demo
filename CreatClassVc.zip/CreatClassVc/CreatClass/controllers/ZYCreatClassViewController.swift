//
//  ZYCreatClassViewController.swift
//  CreatClassDemo
//
//  Created by 苏文潇 on 2018/9/16.
//  Copyright © 2018年 bestsu. All rights reserved.
//

import UIKit

class ZYCreatClassViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = UIColor.white
        setItem()
        setUI()
    }

    private func setItem(){
        self.navigationItem.leftBarButtonItem = UIBarButtonItem.init(title: " 选择班级", imageName: "channelClose", titleColor: UIColor.init(hex6: 0x222222), font: UIFont.systemFont(ofSize: ceilStandardPtf(51)), target: self, action: #selector(leftClick))
    }
    
    @objc private func leftClick(){
        self.navigationController?.popViewController(animated: true)
    }
    private func setUI(){
        self.view.addSubview(classView)
       
        classView.mas_makeConstraints { (make) in
            make?.edges.mas_equalTo()(view)
        }
        
        classView.finishBtnCallBack = {[weak self] (choseArr) in
//            print(choseArr)
//            let vc = ZYFinishCreatClassViewController()
//            self?.navigationController?.pushViewController(vc, animated: true)
            self?.loadData(arr: choseArr)
        }
    }
 
    var gradeStr: String = ""
    var point: String = ""
    private func loadData(arr: [ChoseClassStruct]) {
        for (i, value) in arr.enumerated() {
            let grade = value.grade
            let num = value.classNumber
            let line: String = "-"
            if i == arr.count-1 {
                self.point = ""
            } else {
                self.point = ","
            }
            let all: String = "\(grade)" + line + "\(num)" + point
            self.gradeStr.append(all)
        }
        let parmas: [String: Any] = ["pair": self.gradeStr]
        ZYTeacherCreatClassManager().creatClassData(parmas: parmas, success: { (data) in
            let first: Int = data.info.isFirst
            let inviteCode: String = data.info.inviteCode
            let vc = ZYFinishCreatClassViewController(isFirst: first, inviteCode: inviteCode, classArr: arr)
            self.navigationController?.pushViewController(vc, animated: true)
        }, error: { (msg, code) in
            print(msg, code)
            TKAlertCenter.default().postAlert(withMessage: msg)
        })
    }

    private lazy var classView: ZYTeacherCreatClassView = {
        let view = ZYTeacherCreatClassView()
        return view
    }()
    
}
