//
//  ZYTeacherCreatClassManager.swift
//  iReader
//
//  Created by bestsu on 2018/9/19.
//  Copyright © 2018年 iOS Group. All rights reserved.
//

import UIKit

class ZYTeacherCreatClassManager: NSObject {
    
    override init() {
        super.init()
    }
    
    func creatClassData(parmas: [String: Any], success: @escaping (ZYCreatClassModel)->(), error: @escaping (String, Int)->()){
        
        let urlString = ZYURLManager.teacherCreatClassURL()
        let url:URL = URL.init(string: urlString)!
        ZYHTTPRequest.sendReuqest(with: url, params: parmas, method: ZYHTTPRequestType.POST) { (res) in
            guard let dic = res.responseObject as? [String : Any] else {
                error("无数据...", 0)
                return
            }
            let code = dic["code"] as? Int
            if code != 0{
                let msg = dic["msg"] as? String
                error(msg ?? "", code ?? 10010)
                return
            }
            let model = try? ZYCreatClassModel.init(dictionary: dic)
            guard let data = model else {return}
            success(data)
        }
        
    }
    
///  查询班级列表
    func checkClassList(parmas: [String: Any]? = nil, success: @escaping (ZYGetClassListInfoModel) -> (), error: @escaping (String, Int) -> (Void)) {
        let urlString = ZYURLManager.checkClassListURL()
        let url:URL = URL.init(string: urlString)!
        ZYHTTPRequest.sendReuqest(with: url, params: parmas, method: ZYHTTPRequestType.GET) { (res) in
            guard let dic = res.responseObject as? [String : Any] else {
                error("无数据...", 0)
                return
            }
            let code = dic["code"] as? Int
            if code != 0 {
                let msg = dic["msg"] as? String
                error(msg ?? "", code ?? 10010)
                return
            }
//
            let model = try? ZYStudentGetClassListModel.init(dictionary: dic)
            guard let data = model else {return}
            success(data.info)
        }
        
    }
    
}




