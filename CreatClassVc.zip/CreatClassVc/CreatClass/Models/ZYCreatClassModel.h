//
//  ZYCreatClassModel.h
//  iReader
//
//  Created by bestsu on 2018/9/19.
//  Copyright © 2018年 iOS Group. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface ZYCreatClassListModel : JSONModel

@property (nonatomic, copy) NSString *inviteCode;
@property (nonatomic, assign) NSInteger isFirst;

@end



@interface ZYCreatClassModel : JSONModel

@property (nonatomic, assign) NSInteger code;
@property (nonatomic, copy) NSString *msg;
@property (nonatomic, copy) ZYCreatClassListModel *info;

@end
