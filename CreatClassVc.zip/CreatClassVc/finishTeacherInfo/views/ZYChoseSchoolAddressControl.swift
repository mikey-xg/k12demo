//
//  ZYChoseSchoolAddressControl.swift
//  CreatClassDemo
//
//  Created by bestsu on 2018/9/18.
//  Copyright © 2018年 bestsu. All rights reserved.
//

import UIKit

class ZYChoseSchoolAddressControl: ZYBaseControl {
    /// 名字
    var nameStr: String?{
        didSet{
            self.titleLabel.text = nameStr
        }
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setUI()
    }
    
    override var isSelected: Bool{
        didSet{
            setStyle(isSelect: isSelected)
        }
    }
    
    private func setStyle(isSelect: Bool){
        if isSelected == true{
            self.titleLabel.textColor = UIColor.init(hex6: 0x222222)
        }else{
            self.titleLabel.textColor = UIColor.init(hex: 0x222222, alpha: 0.35)
        }
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func setUI(){
        addSubview(titleLabel)
        
        titleLabel.mas_makeConstraints { (make) in
            make?.right.mas_equalTo()(self)
            make?.centerY.mas_equalTo()(self)
        }
    }
    
    private lazy var titleLabel: UILabel = {
        let label = UILabel()
        label.text = "请选择任教学校"
        label.textAlignment = .right
        label.textColor = UIColor.init(hex: 0x222222, alpha: 0.35)
        label.font = UIFont.systemFont(ofSize: ceilStandardPtf(36))
        return label
    }()
    
    
    
}




