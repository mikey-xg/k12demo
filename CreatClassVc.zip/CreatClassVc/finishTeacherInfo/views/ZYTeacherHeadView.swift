//
//  ZYTeacherHeadView.swift
//  CreatClassDemo
//
//  Created by bestsu on 2018/9/18.
//  Copyright © 2018年 bestsu. All rights reserved.
//

import UIKit

class ZYTeacherHeadView: UIView {

    override init(frame: CGRect) {
        super.init(frame: frame)
        self.backgroundColor = UIColor.white
        setUI()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func setUI(){
        addSubview(headImageView)
        addSubview(editViewBtn)
        
        headImageView.mas_makeConstraints { (make) in
            make?.edges.mas_equalTo()(self) 
        }
        
        editViewBtn.mas_makeConstraints { (make) in
            make?.centerX.bottom().mas_equalTo()(self)
            make?.height.equalTo()(ceilStandardPtf(100))
            make?.width.equalTo()(ceilStandardPtf(240))
        }
    }
    
    @objc private func editViewBtnClick(){
        print("编辑按钮点击")
    }

    private lazy var headImageView: UIImageView = {
        let view = UIImageView()
        view.image = UIImage.init(named: "Group 78")
        return view
    }()
    
    private lazy var editViewBtn: UIButton = {
        let button = UIButton()
        button.adjustsImageWhenHighlighted = false
        button.addTarget(self, action: #selector(editViewBtnClick), for: .touchUpInside)
        return button
    }()
    
}



