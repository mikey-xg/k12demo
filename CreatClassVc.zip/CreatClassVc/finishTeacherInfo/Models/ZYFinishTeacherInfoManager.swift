//
//  ZYFinishTeacherInfoManager.swift
//  iReader
//
//  Created by bestsu on 2018/9/19.
//  Copyright © 2018年 iOS Group. All rights reserved.
//

import UIKit

class ZYFinishTeacherInfoManager: NSObject {

    override init() {
        super.init()
    }
    /// 获取省(市 区 县）
    func loadData(parmas: [String: Any]? = nil, callBack: @escaping ([[ZYFinishTeacherInfoDetaileModel]], [String])->(), errorCallBack: @escaping (String, Int)->()){
        /// 加载数据
        let urlString = ZYURLManager.teacherGetSchoolAddressURL()
        let url:URL = URL.init(string: urlString)!
        ZYHTTPRequest.sendReuqest(with: url, params: parmas, method: ZYHTTPRequestType.GET) { (res) in
            guard let dic = res.responseObject as? [String : Any] else {
                errorCallBack("", 0)
                return
            }
            let code = dic["code"] as? Int
            if code != 0{
                let msg = dic["msg"] as? String
                errorCallBack(msg ?? "", code ?? 10010)
                return
            }
            let model = try? ZYFinishTeacherInfoModel.init(dictionary: dic)
            let dataArr = model?.info as? [ZYFinishTeacherInfoDetaileModel]
            guard let data = dataArr else {return}
            if data.count == 0{
                errorCallBack("body数据为空",10010)
                return
            }
            self.dealData(model: data, callBack: callBack)
        }
    }
    
    //  MARK: - 处理数据
    var titleArr: [String] = ["#"]
    var dataModel:[[ZYFinishTeacherInfoDetaileModel]] = [[ZYFinishTeacherInfoDetaileModel]]()
    var modelArr:[ZYFinishTeacherInfoDetaileModel] = [ZYFinishTeacherInfoDetaileModel]()
    var firstT1: String = ""
    var firstT2: String = ""
    private func dealData(model: [ZYFinishTeacherInfoDetaileModel], callBack: ([[ZYFinishTeacherInfoDetaileModel]], [String])->()){
        for (i, value) in model.enumerated(){
            firstT1 = value.firstLetter
            if firstT2 == firstT1{
                modelArr.append(value)
            }else{
                if modelArr.count != 0{
                    dataModel.append(modelArr)
                }
                modelArr.removeAll()
                modelArr.append(value)
                firstT2 = firstT1
                if i == model.count - 1{
                    dataModel.append(modelArr)
                    modelArr.removeAll()
                }
            }
        }
        for value in self.dataModel{
            self.titleArr.append(value[0].firstLetter)
        }
        callBack(dataModel, titleArr)
    }
    
    
    /// 获取第二级 市(区)
    func loadDataWithAddressGetSchool(parmas: [String: Any]? = nil, callBack: @escaping ([[ZYAddressGetSchoolListModel]], [String])->(), errorCallBack: @escaping (String, Int)->()){
        
        let urlString = ZYURLManager.teacherUseAddressGetSchoolURL()
        let url:URL = URL.init(string: urlString)!
        ZYHTTPRequest.sendReuqest(with: url, params: parmas, method: ZYHTTPRequestType.GET) { (res) in
            guard let dic = res.responseObject as? [String : Any] else {
                errorCallBack("", 0)
                return
            }
            let code = dic["code"] as? Int
            if code != 0{
                let msg = dic["msg"] as? String
                errorCallBack(msg ?? "", code ?? 10010)
                return
            }
            let model = try? ZYAddressGetSchoolModel.init(dictionary: dic)
            let dataArr = model?.info as? [ZYAddressGetSchoolListModel]
            guard let data = dataArr else {return}
            if data.count == 0{
                errorCallBack("body数据为空",10010)
                return
            }
            self.dealSchoolData(model: data, callBack: callBack)
        }
    }
    
    
    //  MARK: - 处理数据
    var schoolModel:[[ZYAddressGetSchoolListModel]] = [[ZYAddressGetSchoolListModel]]()
    var schoolModelArr:[ZYAddressGetSchoolListModel] = [ZYAddressGetSchoolListModel]()
    var firstT3: String = ""
    var firstT4: String = ""
    private func dealSchoolData(model: [ZYAddressGetSchoolListModel], callBack: ([[ZYAddressGetSchoolListModel]], [String])->()){
        for (i, value) in model.enumerated(){
            firstT3 = value.first
            if firstT4 == firstT3{
                schoolModelArr.append(value)
                if i == model.count - 1{
                    schoolModel.append(schoolModelArr)
                    schoolModelArr.removeAll()
                }
            }else{
                if schoolModelArr.count != 0{
                    schoolModel.append(schoolModelArr)
                }
                schoolModelArr.removeAll()
                schoolModelArr.append(value)
                firstT4 = firstT3
                if i == model.count - 1{
                    schoolModel.append(schoolModelArr)
                    schoolModelArr.removeAll()
                }
            }
        }
        for value in self.schoolModel{
            self.titleArr.append(value[0].first)
        }
        callBack(schoolModel, titleArr)
    }
    
    /// 创建老师身份
    func creatTeacherIdentity(parmas: [String: Any], success: @escaping ()->(), error: @escaping (String, Int)->()){
        let urlString = ZYURLManager.creatTeacherIdentifyURL()
        let url:URL = URL.init(string: urlString)!
        ZYHTTPRequest.sendReuqest(with: url, params: parmas, method: ZYHTTPRequestType.POST) { (res) in
            guard let dic = res.responseObject as? [String : Any] else {
                error("无数据...", 0)
                return
            }
            let code = dic["code"] as? Int
            if code != 0{
                let msg = dic["msg"] as? String
                error(msg ?? "", code ?? 10010)
                return
            }
            /// 000013
            success()
        }
        
    }
    
    
}
