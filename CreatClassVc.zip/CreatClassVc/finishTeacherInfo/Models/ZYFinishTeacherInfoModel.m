//
//  ZYFinishTeacherInfoModel.m
//  iReader
//
//  Created by bestsu on 2018/9/18.
//  Copyright © 2018年 iOS Group. All rights reserved.
//

#import "ZYFinishTeacherInfoModel.h"

@implementation ZYFinishTeacherInfoDetaileModel
+ (BOOL)propertyIsOptional:(NSString *)propertyName{
    return YES;
}

@end

@implementation ZYFinishTeacherInfoModel
+ (BOOL)propertyIsOptional:(NSString *)propertyName{
    return YES;
}
+ (JSONKeyMapper *)keyMapper {
    NSDictionary *dict = @{ @"info": @"body" };
    return [[JSONKeyMapper alloc] initWithModelToJSONDictionary:dict];
}



@end



