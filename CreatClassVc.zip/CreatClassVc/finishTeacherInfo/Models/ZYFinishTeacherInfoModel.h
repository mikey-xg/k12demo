//
//  ZYFinishTeacherInfoModel.h
//  iReader
//
//  Created by bestsu on 2018/9/18.
//  Copyright © 2018年 iOS Group. All rights reserved.
//

#import "JSONModel.h"

@protocol ZYFinishTeacherInfoDetaileModel
@end
@interface ZYFinishTeacherInfoDetaileModel : JSONModel
///地区编码
@property (nonatomic, assign) NSInteger areaCode;
///地区名
@property (nonatomic, copy) NSString *areaName;
///首字母
@property (nonatomic, copy) NSString *firstLetter;
///是否结束，0-未结束，还有下级地区  1-已结束，可以开始搜索年级班级
@property (nonatomic, assign) NSInteger isEnd;

@end




@interface ZYFinishTeacherInfoModel : JSONModel

@property (nonatomic, assign) NSInteger code;
@property (nonatomic, copy) NSString *msg;
@property (nonatomic, copy) NSArray<ZYFinishTeacherInfoDetaileModel> *info;

@end
