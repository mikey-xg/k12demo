//
//  ZYAddressGetSchoolModel.m
//  iReader
//
//  Created by bestsu on 2018/9/19.
//  Copyright © 2018年 iOS Group. All rights reserved.
//

#import "ZYAddressGetSchoolModel.h"


@implementation ZYAddressGetSchoolListModel
+ (BOOL)propertyIsOptional:(NSString *)propertyName{
    return YES;
}
@end


@implementation ZYAddressGetSchoolModel
+ (BOOL)propertyIsOptional:(NSString *)propertyName{
    return YES;
}
+ (JSONKeyMapper *)keyMapper {
    NSDictionary *dict = @{ @"info": @"body" };
    return [[JSONKeyMapper alloc] initWithModelToJSONDictionary:dict];
}

@end
