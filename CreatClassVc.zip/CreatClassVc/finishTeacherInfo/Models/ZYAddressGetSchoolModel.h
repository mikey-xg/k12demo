//
//  ZYAddressGetSchoolModel.h
//  iReader
//
//  Created by bestsu on 2018/9/19.
//  Copyright © 2018年 iOS Group. All rights reserved.
//

#import "JSONModel.h"

@protocol ZYAddressGetSchoolListModel
@end

@interface ZYAddressGetSchoolListModel : JSONModel
///上一级地区编码
@property (nonatomic, assign) NSInteger parentCode;
///学校编码
@property (nonatomic, assign) NSInteger schoolCode;
///学校名
@property (nonatomic, copy) NSString *schoolName;
///首字母
@property (nonatomic, copy) NSString *first;

@end



@interface ZYAddressGetSchoolModel : JSONModel

@property (nonatomic, assign) NSInteger code;
@property (nonatomic, copy) NSString *msg;
@property (nonatomic, copy) NSArray<ZYAddressGetSchoolListModel> *info;

@end

