//
//  ZYTeacherFinishInfoViewController.swift
//  CreatClassDemo
//
//  Created by bestsu on 2018/9/18.
//  Copyright © 2018年 bestsu. All rights reserved.
//

import UIKit

class ZYTeacherFinishInfoViewController: ZYBaseViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = UIColor.white
        NotificationCenter.default.addObserver(self, selector: #selector(getSchooolName(noti:)), name: NSNotification.Name("kNotificationSchoolName"), object: nil)
        
        setItem()
        setUI()
    }

    var presentCode: Int = 0 // 上一级地区编码
    var schoolCode:Int = 0 // 学校编码
    var schoolName: String = ""
    @objc private func getSchooolName(noti: Notification){
        let dic: [String: Any] = (noti.object as? [String: Any]) ?? [String: Any]()
        self.presentCode = (dic["parentCode"] as? Int) ?? 0
        self.schoolCode = (dic["schoolCode"] as? Int) ?? 0
        self.schoolName = (dic["schoolName"] as? String) ?? ""
        self.choseSchoolBtn.nameStr = dic["schoolName"] as? String
        self.choseSchoolBtn.isSelected = true
        self.schoolLabel.textColor = UIColor.init(hex: 0x222222)
        
        if (textField.text?.count ?? 0) > 0{
            self.commitBtnView.isSelected = true
        } else {
            self.commitBtnView.isSelected = false
        }
    }
    
    private func setItem() {
        self.navigationItem.leftBarButtonItem = UIBarButtonItem.init(title: "  填写信息", imageName: "channelClose", titleColor: UIColor.init(hex6: 0x222222), font: UIFont.systemFont(ofSize: ceilStandardPtf(51)), target: self, action: #selector(leftClick))
    }
    private func setUI(){
        view.addSubview(commitBtnView)
        view.addSubview(headView)
        view.addSubview(nameLabel)
        view.addSubview(textField)
        view.addSubview(nameLineView)
        
        view.addSubview(schoolLabel)
        view.addSubview(schoolLineView)
        view.addSubview(choseSchoolBtn)
        view.addSubview(iconImageView)
        
        commitBtnView.mas_makeConstraints { (make) in
            make?.centerX.mas_equalTo()(view)
            make?.bottom.equalTo()(ceilStandardPtf(-150))
            make?.size.mas_equalTo()(CGSize(width: ceilStandardPtf(780), height: ceilStandardPtf(129)))
        }
        
        headView.mas_makeConstraints { (make) in
            make?.centerX.mas_equalTo()(view)
            make?.top.equalTo()(ceilStandardPtf(150))
            make?.size.mas_equalTo()(CGSize(width: ceilStandardPtf(300), height: ceilStandardPtf(300)))
        }
        
        nameLabel.mas_makeConstraints { (make) in
            make?.left.equalTo()(ceilStandardPtf(150))
            make?.top.equalTo()(ceilStandardPtf(572))
            make?.height.equalTo()(ceilStandardPtf(60))
        }
        
        nameLineView.mas_makeConstraints { (make) in
            make?.height.equalTo()(ceilStandardPtf(1))
            make?.top.mas_equalTo()(nameLabel.mas_bottom)?.setOffset(ceilStandardPtf(66))
            make?.left.mas_equalTo()(nameLabel)
            make?.width.equalTo()(ceilStandardPtf(780))
        }
        
        textField.mas_makeConstraints { (make) in
            make?.centerY.mas_equalTo()(nameLabel)
            make?.right.mas_equalTo()(nameLineView)
            make?.size.mas_equalTo()(CGSize(width: ceilStandardPtf(500), height: ceilStandardPtf(120)))
        }
        
        schoolLabel.mas_makeConstraints { (make) in
            make?.left.mas_equalTo()(nameLabel)
            make?.top.mas_equalTo()(nameLineView.mas_bottom)?.setOffset(72)
             make?.height.equalTo()(ceilStandardPtf(60))
            make?.width.equalTo()(ceilStandardPtf(110))
        }
        
        iconImageView.mas_makeConstraints { (make) in
            make?.right.mas_equalTo()(nameLineView)
            make?.centerY.mas_equalTo()(schoolLabel)
            make?.size.mas_equalTo()(CGSize(width: ceilStandardPtf(43), height: ceilStandardPtf(43)))
        }

        choseSchoolBtn.mas_makeConstraints { (make) in
            make?.right.mas_equalTo()(iconImageView.mas_left)
            make?.centerY.mas_equalTo()(schoolLabel)
            make?.left.mas_equalTo()(schoolLabel.mas_right)?.setOffset(ceilStandardPtf(20))
            make?.height.equalTo()(ceilStandardPtf(60))
        }

        schoolLineView.mas_makeConstraints { (make) in
            make?.top.mas_equalTo()(schoolLabel.mas_bottom)?.setOffset(ceilStandardPtf(60))
            make?.left.height().right().mas_equalTo()(nameLineView)
        }
    }

    @objc private func commitBtnViewClick(){
        print("提交点击")
        if commitBtnView.isSelected == true{
            loadData()
        }
    }
    
    @objc private func leftClick() {
        self.navigationController?.popViewController(animated: true)
    }
    
    @objc private func textFieldClick(){
        textField.text = textField.text?.replacingOccurrences(of: " ", with: "")
        if (textField.text?.count ?? 0) > 0 {
            self.nameLabel.textColor = UIColor.init(hex: 0x222222)
        } else {
            self.nameLabel.textColor = UIColor.init(hex: 0x222222, alpha: 0.15)
        }
        if (textField.text?.count ?? 0) <= 0 {
            self.commitBtnView.isSelected = false
        } else {
            if choseSchoolBtn.nameStr != "请选择任教学校" {
                self.commitBtnView.isSelected = true
            } else {
                self.commitBtnView.isSelected = false
            }
        }
    }
    
    @objc private func choseSchoolBtnClick(){
        print("选择学校")
        let vc = ZYChoseAddressViewController()
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    /// 提交申请
    private func loadData() {
        let usr = self.textField.text ?? ""
        let parmas: [String: Any] = ["userName": usr, "school": "\(schoolCode)"]
        ZYFinishTeacherInfoManager().creatTeacherIdentity(parmas: parmas, success: {
            let vc = ZYApproveApplicationViewController()
            self.navigationController?.pushViewController(vc, animated: true)
            NotificationCenter.default.post(name: NSNotification.Name("TEACHERFINISHINFOMATION"), object: nil)
        }) { (msg, code) in
            print(msg, code)
            TKAlertCenter.default().postAlert(withMessage: msg)
        }
    }
 
    private lazy var commitBtnView: UIButton = {
        let view = UIButton()
        view.adjustsImageWhenHighlighted = false
        view.setTitle("提交申请", for: .normal)
        view.isSelected = false
        view.setBackgroundImage(UIImage.init(named: "button copy"), for: .normal)
        view.setBackgroundImage(UIImage.init(named: "button"), for: .selected)
        view.layer.cornerRadius = ceilStandardPtf(12)
        view.layer.masksToBounds = true
        view.setTitleColor(UIColor.white, for: .normal)
        view.titleLabel?.font = UIFont.systemFont(ofSize: ceilStandardPtf(48))
        view.addTarget(self, action: #selector(commitBtnViewClick), for: .touchUpInside)
        return view
    }()
  
    private lazy var nameLabel: UILabel = {
        let label = UILabel()
        label.text = "姓名"
        label.textAlignment = .center
        label.textColor = UIColor.init(hex: 0x222222, alpha: 0.15)
        label.font = UIFont.systemFont(ofSize: ceilStandardPtf(48))
        return label
    }()
    
    private lazy var textField: UITextField = {
        let textField = UITextField()
        textField.borderStyle = .none
        textField.placeholder = "真实姓名可便于学生找到您"
        textField.textAlignment = .right
        textField.font = UIFont.systemFont(ofSize: ceilStandardPtf(36))
        textField.addTarget(self, action: #selector(textFieldClick), for: .editingChanged)
        return textField
    }()
    
    private lazy var nameLineView: UIView = {
        let view = UIView()
        view.backgroundColor = UIColor.init(hex: 0x222222, alpha: 0.1)
        return view
    }()
    
    private lazy var headView: ZYTeacherHeadView = {
        let view = ZYTeacherHeadView()
        return view
    }()
    
    private lazy var schoolLabel: UILabel = {
        let label = UILabel()
        label.text = "学校"
        label.textAlignment = .center
        label.textColor = UIColor.init(hex: 0x222222, alpha: 0.15)
        label.font = UIFont.systemFont(ofSize: ceilStandardPtf(48))
        return label
    }()
    
    private lazy var schoolLineView: UIView = {
        let view = UIView()
        view.backgroundColor = UIColor.init(hex: 0x222222, alpha: 0.1)
        return view
    }()
    
    private lazy var choseSchoolBtn: ZYChoseSchoolAddressControl = {
        let view = ZYChoseSchoolAddressControl()
        view.isSelected = false
        view.nameStr = "请选择任教学校"
        view.addTarget(self, action: #selector(choseSchoolBtnClick), for: .touchUpInside)
        return view
    }()
    
    private lazy var iconImageView: UIImageView = {
        let view = UIImageView()
        view.image = UIImage.init(named: "icon_all_jump")
        return view
    }()
}
