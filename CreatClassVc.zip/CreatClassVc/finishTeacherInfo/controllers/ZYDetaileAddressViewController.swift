//
//  ZYDetaileAddressViewController.swift
//  iReader
//
//  Created by bestsu on 2018/9/19.
//  Copyright © 2018年 iOS Group. All rights reserved.
//

import UIKit

class ZYDetaileAddressViewController: ZYBaseViewController, UITableViewDelegate, UITableViewDataSource{

    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = UIColor.white
        customNavigationBarShadowColor = UIColor.clear
        setItem()
        setUI()
    }
    
    
    var addCode: Int = 0
    var addTitle: String = ""
    var endCode: Int = -1
    /// 带地区编号
    ///
    /// - Parameter code: 地区编号
    convenience init(code: Int, addStr: String, isEndCode: Int){
        self.init()
        self.addCode = code
        self.addTitle = addStr
        self.titleLabel.text = addStr
        self.endCode = isEndCode
        if isEndCode == 0{
             loadData()
        }else{
            self.getSchool(code: code)
        }
    }
    
    private func setItem(){
        self.navigationItem.leftBarButtonItem = UIBarButtonItem.init(title: " 选择学校", imageName: "channelClose", titleColor: UIColor.init(hex6: 0x222222), font: UIFont.systemFont(ofSize: ceilStandardPtf(51)), target: self, action: #selector(leftClick))
    }

    private func setUI(){
        view.addSubview(titleLabel)
        view.addSubview(tableView)
        
        titleLabel.mas_makeConstraints { (make) in
            make?.right.top().mas_equalTo()(view)
            make?.left.equalTo()(ceilStandardPtf(40))
            make?.height.equalTo()(ceilStandardPtf(147))
        }
        
        tableView.mas_makeConstraints { (make) in
            make?.left.right().bottom().mas_equalTo()(view)
            make?.top.mas_equalTo()(titleLabel.mas_bottom)
        }
        
    }
    
    //  MARK:  - uitableview的代理方法和数据源方法
    func numberOfSections(in tableView: UITableView) -> Int {
        if endCode == 0{
            return self.dataModel.count
        }else{
            return self.schoolDataM.count
        }
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if endCode == 0{
            return self.dataModel[section].count
        }else{
            return self.schoolDataM[section].count
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cellId", for: indexPath)
        if endCode == 0{
            cell.textLabel?.text = self.dataModel[indexPath.section][indexPath.row].areaName
        }else{
            cell.textLabel?.text = self.schoolDataM[indexPath.section][indexPath.row].schoolName
        }
        return cell
    }
    
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        if endCode == 0{
            let arr = self.dataModel[section]
            return arr[0].firstLetter
        }else{
            let arr = self.schoolDataM[section]
            return arr[0].first
        }
    }
    
    func tableView(_ tableView: UITableView, willDisplayHeaderView view: UIView, forSection section: Int) {
        let header = view as? UITableViewHeaderFooterView
        header?.textLabel?.textColor = UIColor.init(hex: 0x222222, alpha: 0.35)
        header?.contentView.backgroundColor = UIColor.init(hex: 0xf3f3f3)
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        //  isEnd == 1 表示没有了， == 0.表示还有
        if endCode == 0{
            let isEndCode: Int = self.dataModel[indexPath.section][indexPath.row].isEnd
            let code: Int = self.dataModel[indexPath.section][indexPath.row].areaCode
            let str: String = self.dataModel[indexPath.section][indexPath.row].areaName
            let addressStr: String = (titleLabel.text ?? "") + str
            let vc = ZYDetaileAddressViewController(code: code, addStr: addressStr, isEndCode: isEndCode)
            self.navigationController?.pushViewController(vc, animated: true)
        }else{
            let schoolName = self.schoolDataM[indexPath.section][indexPath.row].schoolName
            let schoolCode = self.schoolDataM[indexPath.section][indexPath.row].schoolCode
            let parentCode = self.schoolDataM[indexPath.section][indexPath.row].parentCode
            let dic: [String: Any] = ["schoolName":schoolName ?? "", "schoolCode":schoolCode, "parentCode":parentCode]
            self.navigationController?.popToViewController(toVC: "ZYTeacherFinishInfoViewController", animated: true, completion: {
                NotificationCenter.default.post(name: NSNotification.Name("kNotificationSchoolName"), object: dic)
            })
        }
        
    }
    

    @objc private func leftClick(){
        self.navigationController?.popViewController(animated: true)
    }

    
    /// 加载数据
    var titleArr: [String]?
    var dataModel:[[ZYFinishTeacherInfoDetaileModel]] = [[ZYFinishTeacherInfoDetaileModel]]()
    private func loadData(){
        let parmas: [String: Any] = ["code": "\(self.addCode)"]
        ZYFinishTeacherInfoManager().loadData(parmas: parmas,callBack: {[weak self] (detalieM, titleM) in
            self?.tableView.isHidden = false
            self?.dataModel = detalieM
            self?.titleArr = titleM
            self?.tableView.reloadData()
            self?.setList()
        }) { (msg, code) in
            print(msg, code)
        }
    }
    
    var schoolDataM: [[ZYAddressGetSchoolListModel]] = [[ZYAddressGetSchoolListModel]]()
    private func getSchool(code: Int){ //ZYAddressGetSchoolListModel
        let parmas: [String: Any] = ["code": "\(code)"]
        ZYFinishTeacherInfoManager().loadDataWithAddressGetSchool(parmas: parmas, callBack: { (dataM, titleM) in
            self.schoolDataM = dataM
            self.titleArr = titleM
            self.tableView.reloadData()
            self.setList()
        }) { (msg, code) in
            print(msg, code)
        }
    }
    
    
    //  MARK: - 索引加载
    private func setList(){
        let indexViewConfiguration = SCIndexViewConfiguration.init(indexViewStyle: SCIndexViewStyle.default)
        let indexView = SCIndexView.init(tableView: self.tableView, configuration: indexViewConfiguration)
        self.view.addSubview(indexView!)
        indexView?.dataSource = self.titleArr
    }
    
    //  MARK:  - 懒加载控件
    private lazy var titleLabel: UILabel = {
        let label = UILabel()
        label.text = ""
        label.textAlignment = .left
        label.backgroundColor = UIColor.white
        label.textColor = UIColor.init(hex: 0x08AAE6)
        label.font = UIFont.systemFont(ofSize: ceilStandardPtf(51))
        return label
    }()
    
    private lazy var tableView: UITableView = {
        let view = UITableView(frame: CGRect.zero, style: .plain)
        view.delegate = self
        view.dataSource = self
        view.separatorStyle = .none
        view.register(UITableViewCell.classForCoder(), forCellReuseIdentifier: "cellId")
        return view
    }()
    
    
}




