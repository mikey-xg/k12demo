//
//  ZYApproveApplicationViewController.swift
//  iReader
//
//  Created by bestsu on 2018/9/19.
//  Copyright © 2018年 iOS Group. All rights reserved.
//

import UIKit
/// 认证申请提交
class ZYApproveApplicationViewController: ZYBaseViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = UIColor.white
        customNavigationBarShadowEnable = true
        customNavigationBarShadowColor = UIColor.clear
        setItem()
        setUI()
    }

    private func setItem(){
        self.navigationItem.leftBarButtonItem = UIBarButtonItem.init(title: "  提交申请", imageName: "channelClose", titleColor: UIColor.init(hex6: 0x222222), font: UIFont.systemFont(ofSize: ceilStandardPtf(51)), target: self, action: #selector(leftClick))
    }
    
    @objc private func leftClick(){
        self.navigationController?.popViewController(animated: true)
    }
    
    //  MARK: - 创建班级按钮
    @objc private func creatClassClick(){
        let vc = ZYCreatClassViewController()
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    private func setUI(){
        view.addSubview(iconImageView)
        view.addSubview(infoLabel)
        view.addSubview(titleLabel)
        view.addSubview(creatClassBtn)
        
        iconImageView.mas_makeConstraints { (make) in
            make?.centerX.mas_equalTo()(view)
            make?.top.equalTo()(ceilStandardPtf(123))
            make?.size.mas_equalTo()(CGSize(width: ceilStandardPtf(290), height: ceilStandardPtf(290)))
        }
        
        infoLabel.mas_makeConstraints { (make) in
            make?.centerX.mas_equalTo()(view)
            make?.top.mas_equalTo()(iconImageView.mas_bottom)?.setOffset(ceilStandardPtf(72))
        }
        
        titleLabel.mas_makeConstraints { (make) in
            make?.centerX.mas_equalTo()(view)
            make?.top.mas_equalTo()(infoLabel.mas_bottom)?.setOffset(ceilStandardPtf(60))
        }
        
        creatClassBtn.mas_makeConstraints { (make) in
            make?.centerX.mas_equalTo()(view)
            make?.bottom.equalTo()(ceilStandardPtf(-510))
            make?.size.mas_equalTo()(CGSize(width: ceilStandardPtf(840), height: ceilStandardPtf(135)))
        }
        
    }
    
    //  MARK: - 懒加载控件
    private lazy var iconImageView: UIImageView = {
        let view = UIImageView()
        view.image = UIImage.init(named: "image_recharge_success")
        return view
    }()
    
    private lazy var infoLabel: UILabel = {
        let label = UILabel()
        label.text = "认证申请已提交"
        label.textAlignment = .center
        label.textColor = UIColor.init(hex: 0x2bc17c)
        label.font = UIFont.boldSystemFont(ofSize: ceilStandardPtf(48))
        return label
    }()
    
    private lazy var titleLabel: UILabel = {
        let label = UILabel()
        label.text = "预计1-2个工作日审核完毕\n可在个人中心查看认证状态"
        label.textAlignment = .center
        label.numberOfLines = 0
        label.textColor = UIColor.init(hex: 0x222222, alpha: 0.35)
        label.font = UIFont.systemFont(ofSize: ceilStandardPtf(42))
        return label
    }()
    
    private lazy var creatClassBtn: UIButton = {
        let button = UIButton()
        button.adjustsImageWhenHighlighted = false
        button.setTitle("创建班级", for: .normal)
        button.setBackgroundImage(UIImage.init(named: "button"), for: .normal)
        button.titleLabel?.font = UIFont.systemFont(ofSize: ceilStandardPtf(48))
        button.setTitleColor(UIColor.white, for: .normal)
        button.addTarget(self, action: #selector(creatClassClick), for: .touchUpInside)
        return button
    }()
    
}





