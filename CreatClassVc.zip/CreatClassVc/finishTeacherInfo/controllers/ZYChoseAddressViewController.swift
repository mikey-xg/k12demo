//
//  ZYChoseAddressViewController.swift
//  CreatClassDemo
//
//  Created by bestsu on 2018/9/18.
//  Copyright © 2018年 bestsu. All rights reserved.
//

import UIKit


class ZYChoseAddressViewController: ZYBaseViewController, UITableViewDelegate, UITableViewDataSource{

    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = UIColor.white
        customNavigationBarShadowColor = UIColor.clear
        setItem()
        setUI()
        loadData()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.navigationBar.isTranslucent = true
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        self.navigationController?.navigationBar.isTranslucent = false
    }

    private func setItem(){
        self.navigationItem.leftBarButtonItem = UIBarButtonItem.init(title: " 选择学校", imageName: "channelClose", titleColor: UIColor.init(hex6: 0x222222), font: UIFont.systemFont(ofSize: ceilStandardPtf(51)), target: self, action: #selector(leftClick))
    }
    
    @objc private func leftClick(){
        self.navigationController?.popViewController(animated: true)
    }
    
    private func setUI(){
        view.addSubview(tableView)
        tableView.frame = self.view.frame
    }
    
 
    //  MARK: - tableview的代理方法和数据源方法
    func numberOfSections(in tableView: UITableView) -> Int {
        return self.dataModel.count
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.dataModel[section].count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cellId", for: indexPath)
        cell.textLabel?.text = self.dataModel[indexPath.section][indexPath.row].areaName
        return cell
    }
    
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        let arr = self.dataModel[section]
        return arr[0].firstLetter
    }
    
    func tableView(_ tableView: UITableView, willDisplayHeaderView view: UIView, forSection section: Int) {
        let header = view as? UITableViewHeaderFooterView
        header?.textLabel?.textColor = UIColor.init(hex: 0x222222, alpha: 0.35)
        header?.contentView.backgroundColor = UIColor.init(hex: 0xf3f3f3)
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        //  isEnd == 1 表示没有了， == 0.表示还有
        let isEndCode: Int = self.dataModel[indexPath.section][indexPath.row].isEnd
        let code: Int = self.dataModel[indexPath.section][indexPath.row].areaCode
        let str: String = self.dataModel[indexPath.section][indexPath.row].areaName
        let vc = ZYDetaileAddressViewController(code: code, addStr: str, isEndCode: isEndCode)
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    /// 加载数据
    var titleArr: [String]?
    var dataModel:[[ZYFinishTeacherInfoDetaileModel]] = [[ZYFinishTeacherInfoDetaileModel]]()
    private func loadData(){
        ZYFinishTeacherInfoManager().loadData(callBack: {[weak self] (detalieM, titleM) in
            self?.tableView.isHidden = false
            self?.dataModel = detalieM
            self?.titleArr = titleM
            self?.tableView.reloadData()
            self?.setList()
        }) { (msg, code) in
            print(msg, code)
        }
    }
    
//  MARK: - 索引加载
    private func setList(){
        let indexViewConfiguration = SCIndexViewConfiguration.init(indexViewStyle: SCIndexViewStyle.default)
        let indexView = SCIndexView.init(tableView: self.tableView, configuration: indexViewConfiguration)
        self.view.addSubview(indexView!)
        indexView?.dataSource = self.titleArr
    }

    //  MARK:  - 懒加载控件
    private lazy var tableView: UITableView = {
        let view = UITableView(frame: CGRect.zero, style: .plain)
        view.delegate = self
        view.dataSource = self
        view.isHidden = true
        view.rowHeight = ceilStandardPtf(138)
        view.register(UITableViewCell.classForCoder(), forCellReuseIdentifier: "cellId")
        return view
    }()

}





